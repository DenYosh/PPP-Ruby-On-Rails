class Department < ApplicationRecord
  has_many :employees
end
