class Country < ApplicationRecord
  has_many :employees
end
